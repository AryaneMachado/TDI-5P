package br.edu.ifsuldeminas.mch.suap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SuapApplication {

	public static void main(String[] args) {
		SpringApplication.run(SuapApplication.class, args);
	}

}
